JUNIOR DANGOTE TWIN — HOME SCREEN APP FILES

Upload these files to the ROOT of the GitHub repository, preserving the assets folder:
- manifest.webmanifest
- service-worker.js
- apple-touch-icon.png
- assets/hacker-pro-icon-192.png
- assets/hacker-pro-icon-512.png

Then edit index.html:
1. In <head>, immediately after the existing theme-color meta tag, add:
   <meta name="apple-mobile-web-app-capable" content="yes">
   <meta name="apple-mobile-web-app-title" content="Junior Twin">
   <meta name="mobile-web-app-capable" content="yes">
   <link rel="manifest" href="./manifest.webmanifest">
   <link rel="icon" type="image/png" sizes="192x192" href="./assets/hacker-pro-icon-192.png">
   <link rel="apple-touch-icon" href="./apple-touch-icon.png">

2. Immediately before </body>, after the existing app.js script, add:
   <script>
   if ("serviceWorker" in navigator) {
     window.addEventListener("load", () => {
       navigator.serviceWorker.register("./service-worker.js").catch(console.error);
     });
   }
   </script>

Commit all changes to main. The service worker provides a basic cached app shell; API requests to other domains are not cached.
